public class MousePressMsg extends Message {
  public int x;
  public int y;

  public MousePressMsg(int X, int Y){
    x = X;
    y = Y;
  }

}