/*
 * Author: 13844768
 * Created: 09 April 2003 09:52:07 PM
 * Modified: 09 April 2003 09:52:07 PM
 */


public interface DoObject
{
	public void run();

}
