public class Message {
  public Message(){
  }  

}