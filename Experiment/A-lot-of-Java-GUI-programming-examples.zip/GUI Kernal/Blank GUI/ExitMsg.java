public class ExitMsg extends Message {

  public ExitMsg(){}

}