public class TerminateBroadcastException extends RuntimeException {  

public TerminateBroadcastException(String err) {
  super(err);
}

}