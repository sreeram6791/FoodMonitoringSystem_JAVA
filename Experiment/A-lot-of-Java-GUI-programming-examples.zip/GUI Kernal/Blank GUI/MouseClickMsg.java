public class MouseClickMsg extends Message {
  public int x;
  public int y;

  public MouseClickMsg(int X, int Y){
    x = X;
    y = Y;
  }

}