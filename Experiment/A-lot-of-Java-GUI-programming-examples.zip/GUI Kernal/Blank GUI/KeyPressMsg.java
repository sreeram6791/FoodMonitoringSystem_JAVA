public class KeyPressMsg extends Message {
  public char stream;
  
  KeyPressMsg(char C){
    stream = C;
  }
}