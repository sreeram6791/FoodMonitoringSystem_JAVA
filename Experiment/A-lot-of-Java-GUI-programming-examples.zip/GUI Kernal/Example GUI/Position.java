/*
 * Author: 13844768
 * Created: 02 April 2003 01:50:45 AM
 * Modified: 02 April 2003 01:50:45 AM
 */


public interface Position
{	
	public Object element();

}
