/*
 * Author: 13844768
 * Created: 12 April 2003 06:11:37 PM
 * Modified: 12 April 2003 06:11:37 PM
 */


class InterActivePolyObject
{
	

}
