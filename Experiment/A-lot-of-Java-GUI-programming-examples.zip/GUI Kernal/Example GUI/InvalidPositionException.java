/*
 * Author: Domino
 * Created: 03/13/2003 16:03:20
 * Modified: 03/13/2003 16:03:20
 */

public class InvalidPositionException extends RuntimeException
{
	public InvalidPositionException(String err){
		super(err);
	}	

}
