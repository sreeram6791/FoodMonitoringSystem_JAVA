/*
 * Author: 13844768
 * Created: 03 April 2003 06:33:01 PM
 * Modified: 03 April 2003 06:33:01 PM
 */


public interface Locator
{
	public Object element();
	public Object key();	

}
