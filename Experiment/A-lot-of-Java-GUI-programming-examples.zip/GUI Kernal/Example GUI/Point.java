/*
 * Author: 13844768
 * Created: 14 April 2003 09:20:11 PM
 * Modified: 14 April 2003 09:20:11 PM
 */


public class Point
{
	protected int X,Y;
	
	public Point(int x, int y){
		X = x;
		Y= y;
	}

	public int getX(){
		return X;
	}
	
	public int getY(){
		return Y;
	}
	
}