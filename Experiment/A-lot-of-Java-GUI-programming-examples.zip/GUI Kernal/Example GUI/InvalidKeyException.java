/*
 * Author: Domino
 * Created: 03/15/2003 14:32:40
 * Modified: 03/15/2003 14:32:40
 */


public class InvalidKeyException extends RuntimeException
{
	public InvalidKeyException(String err){
		super(err);
	}	
	
}