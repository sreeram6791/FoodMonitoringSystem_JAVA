import java.awt.*;

public class GUIPolyVertex extends InterActivePolyObject{
	public GUIPolyVertex(){
		super();
	}
}