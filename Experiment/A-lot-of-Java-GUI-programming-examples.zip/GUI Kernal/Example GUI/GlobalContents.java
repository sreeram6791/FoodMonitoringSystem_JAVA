/*
 * Author: 13844768
 * Created: 13 April 2003 07:49:10 PM
 * Modified: 13 April 2003 07:49:10 PM
 */


public class GlobalContents
{
	public static TextTransision TextTr;
	public static int Width,Height;

	

}
