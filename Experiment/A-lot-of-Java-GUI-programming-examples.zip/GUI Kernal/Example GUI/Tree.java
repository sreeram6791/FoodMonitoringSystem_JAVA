/*
 * Author: Domino
 * Created: 03/15/2003 16:26:13
 * Modified: 03/15/2003 16:26:13
 */


public interface Tree extends InspectableTree, PositionalContainer
{
	

}
