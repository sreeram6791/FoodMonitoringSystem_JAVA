/*
 * Author: Domino
 * Created: 03/15/2003 16:39:50
 * Modified: 03/15/2003 16:39:50
 */


public interface InspectableContainer
{
	public int size();
	public boolean isEmpty();

}
