/*
 * Author: 13844768
 * Created: 02 April 2003 02:27:56 AM
 * Modified: 02 April 2003 02:27:56 AM
 */


public class AttributeNotFoundException extends RuntimeException
{
	public AttributeNotFoundException(String err){
		super(err);
	}	
	
}