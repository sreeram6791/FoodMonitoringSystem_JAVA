/*
 * Author: Domino
 * Created: 03/15/2003 16:37:26
 * Modified: 03/15/2003 16:37:26
 */


public interface InspectablePositionalContainer extends InspectableContainer
{
//	public PositionIterator positions();
}
