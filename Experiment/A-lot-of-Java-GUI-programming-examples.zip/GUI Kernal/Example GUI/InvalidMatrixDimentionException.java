public class InvalidMatrixDimentionException extends RuntimeException
{
	public InvalidMatrixDimentionException(String err){
		super(err);
	}	
	
}