/*
 * Author: Domino
 * Created: 03/15/2003 15:47:34
 * Modified: 03/15/2003 15:47:34
 */


public interface BinaryTree extends InspectableBinaryTree, PositionalContainer{
}
