/*
 * Author: 13844768
 * Created: 17 April 2003 12:46:15 AM
 * Modified: 17 April 2003 12:46:15 AM
 */


public class CustomString implements DoObject
{
	public CustomString(){}
	
	public void run(){
		Intro.StringA.Str = "FARSTDBWCFG";
		Intro.StringB.Str = "AGFDFRGRGST";	
	}

}
